﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidPrinciples.InterfacesSegregate
{
    
    public class Document
    {
    }
}
